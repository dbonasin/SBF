testAOI <- function(map, size_of_cell, S){
  grid <- st_make_grid(map, crs = 4326, cellsize = size_of_cell) %>%
    st_sf('geometry' = ., data.frame('ID' = 1:length(.)))
  
  # It takes 80% of cells from whole grid for testing
  num_of_rows <- nrow(grid)
  grid[sample(num_of_rows, num_of_rows * 0.8), ]
  
  grid["label"] <- 0
  # It transfers the labels for cells from S(they are in bloom filter) to grid
  common <- intersect(grid$ID, S$ID) 
  for (i in common) {
      grid[which(grid$ID == i),]$label <- S[which(S$ID == i),]$label
  }
  
  return(grid)
}

#__________________________________________________________________________________
# TODO: decide if the cell size will be fixed(as in paper) or should Be dependand on the amount of the cells overall
# TODO: download shape file(map of Croatia or something)
#✓ TODO: use this to make the circle buffer https://community.rstudio.com/t/sf-function-that-can-find-all-available-polygones-to-a-point-within-a-certain-radius/114318/2
#   TODO: calculate circle radius in meters, correctly!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#✓ TODO: make a grid -> https://gis.stackexchange.com/questions/225157/generate-rectangular-fishnet-or-vector-grid-cells-shapefile-in-r
#✓ TODO: intersect grid with buffer
#✓ TODO: take only those intersected cells
# TODO: calculate manhattan distance
#   TODO: Make have cells x and y labels: https://gis.stackexchange.com/questions/334495/r-spatstat-sp-sf-grid-a-single-polygon-divide-alphanumeric-labels-based-o

library(sf)
library(ggplot2)
library(raster)
library(fasterize)
library(tmap)
library(tmaptools)
library(rnaturalearth)

coverageAOI <- function(map, point, radius, size_of_cell, partition_count){
  # buffer is circle around the center point
  buffer <- st_buffer(point, radius)
  
  # making grid over the map and size of cell is expressed in degrees
  grid <- st_make_grid(map, crs = 4326, cellsize = size_of_cell) %>%
    st_sf('geometry' = ., data.frame('ID' = 1:length(.)))
  
  rasterizedGrid <- fasterize::raster(grid, resolution=c(size_of_cell,size_of_cell), crs = 4326)
  
  

  # get X and Y from row and col numbers
  grid$X <- raster::colFromCell(rasterizedGrid, grid$ID)
  grid$Y <- raster::rowFromCell(rasterizedGrid, grid$ID)


  # intersection with buffer as a polygon
  grid$intersects_buffer <- ifelse(sf::st_intersects(grid, buffer, sparse = F),
                               "Yes",
                               "No")

  # does the cell have center
  grid$has_center <- ifelse(sf::st_intersects(grid, point, sparse = F),
                           "Yes",
                           "No")

  # Selecting only those cells which contain the buffer
  S <- grid[which(grid$intersects_buffer == "Yes"),]
  # 
  return(partitionAOI(manhattanDistanceAOI(S), partition_count))
}

manhattanDistanceAOI <- function(S){
  x <- S[which(S$has_center == "Yes"),]$X
  y <- S[which(S$has_center == "Yes"),]$Y
  
  label <- c()
  element <- c()
  S["manDist"] <- NA

  for (i in 1:nrow(S)) {
    S[i,]$manDist <- abs(x - S[i,]$X) + abs(y - S[i,]$Y)
  }
  # 
  # manDist <- c()
  # 
  # for (i in 1:nrow(S)) {
  #   manDist <- c(manDist, abs(x - S[i,]$X) + abs(y - S[i,]$Y))
  # }
  # 
  # S$manDist <- manDist
  return(S)
}

partitionAOI <- function(S, partition_count){
  S["label"] <- NA
  max_distance <- max(S$manDist)
  partition_length <- floor((max_distance + 1) / partition_count)
  m <- (max_distance + 1) %% partition_count
  
  for (i in 1:partition_count) {
    if (m != 0){
      S[which(S$manDist >= (max_distance - partition_length) & S$manDist <= max_distance),]$label <- i
      
      max_distance <- max_distance - (partition_length + 1)
      m <- m - 1
    } else {
      S[which(S$manDist >= (max_distance - partition_length + 1) & S$manDist <= max_distance),]$label <- i
      
      max_distance <- max_distance - partition_length
    }
  }
  
  return(S)
}